
Partial Class Forms_frmCompanyBranch
    Inherits System.Web.UI.Page

End Class
